package foodDeliverySystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CustomerMenu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerMenu frame = new CustomerMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerMenu() {
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 458, 700);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(CustomerMenu.class.getResource("/foodDeliverySystem/logo.png")));
		lblNewLabel.setBounds(44, 0, 301, 121);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				CreateCustomerAccount customerAccountWindow = new CreateCustomerAccount();
				customerAccountWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBorderPainted(false);
		btnNewButton.setOpaque(false);
		btnNewButton.setFocusPainted(false);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setIcon(new ImageIcon(CustomerMenu.class.getResource("/foodDeliverySystem/CreateAccount.png")));
		btnNewButton.setBounds(22, 148, 181, 121);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_3 = new JButton("New button");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				LeaveFeedback lf =  new LeaveFeedback();
				lf.setVisible(true);
				dispose();
						
				
			}
		});
		btnNewButton_3.setBorderPainted(false);
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setIcon(new ImageIcon(CustomerMenu.class.getResource("/foodDeliverySystem/LeaveFeedback.png")));
		btnNewButton_3.setBounds(118, 265, 181, 109);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_6 = new JButton("");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				MainMenu mainMenuWindow = new MainMenu();
				mainMenuWindow.setVisible(true);
				dispose();
			
			}
		});
		btnNewButton_6.setIcon(new ImageIcon(CustomerMenu.class.getResource("/foodDeliverySystem/home.jpg")));
		btnNewButton_6.setBounds(153, 398, 119, 109);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_5 = new JButton("New button");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				NewOrder newOrderWindow = new NewOrder();
				newOrderWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_5.setBorderPainted(false);
		btnNewButton_5.setBackground(Color.WHITE);
		btnNewButton_5.setIcon(new ImageIcon(CustomerMenu.class.getResource("/foodDeliverySystem/NewOrder.png")));
		btnNewButton_5.setBounds(225, 154, 194, 109);
		contentPane.add(btnNewButton_5);
	}

}
