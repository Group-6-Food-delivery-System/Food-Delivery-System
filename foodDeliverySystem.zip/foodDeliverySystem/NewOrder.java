package foodDeliverySystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import javax.swing.JComboBox;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.Component;

public class NewOrder extends JFrame {
	
	static Connection connection = null;
	static String databaseName = "food_delivery_system";
	static String url = "jdbc:mysql://127.0.0.1:3306/?user=root" + databaseName;
	static String username = "root";
	static String password = "AmmiAbbu6353123!";
	

	private JPanel contentPane;
	private JTextField dateText;
	private JTextField amountText;
	private JTextField CustIdText;
	private JLabel lblNewLabel_3;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JLabel msgLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewOrder frame = new NewOrder();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewOrder() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 394, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Date");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(28, 210, 94, 14);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		comboBox.setBackground(Color.WHITE);
		comboBox.setBounds(28, 357, 203, 22);
		contentPane.add(comboBox);
		
		dateText = new JTextField();
		dateText.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) 
			{
				try 
				{
					Class.forName("com.mysql.jdbc.Driver").getDeclaredConstructor().newInstance();
					connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/food_delivery_system?user=root&password=AmmiAbbu6353123!");
					Statement stmt = connection.createStatement();
					String query = "SELECT CardNumber, Expiration FROM creditcardinfo WHERE CustomerID = " + CustIdText.getText();
					
					PreparedStatement ps = connection.prepareStatement(query);
					ResultSet rs  = stmt.executeQuery(query);
					
					while (rs.next())
					{
						String creditCardNumber = rs.getString("CardNumber" ) + " ,  Exp: " +  rs.getString("Expiration");
						comboBox.addItem(creditCardNumber);
						//comboBox.addElement(new DemoModelItem(rs.getString("CardNumber"),rs.getString("Expiration")));
						
						
					}
					connection.close();
					
				} catch(Exception e1) {}
			}
		});
		dateText.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		dateText.setBounds(28, 235, 117, 20);
		contentPane.add(dateText);
		dateText.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Amount");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12)); 
		lblNewLabel_1.setBounds(28, 266, 94, 14);
		contentPane.add(lblNewLabel_1);
		
		amountText = new JTextField();
		amountText.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		amountText.setBounds(28, 291, 86, 20);
		contentPane.add(amountText);
		amountText.setColumns(10);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBorderPainted(false);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setIcon(new ImageIcon(NewOrder.class.getResource("/foodDeliverySystem/NewOrder.png")));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Class.forName("com.mysql.jdbc.Driver").getDeclaredConstructor().newInstance();
					connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/food_delivery_system?user=root&password=AmmiAbbu6353123!");
					
					Statement stmt = connection.createStatement();
					
					String query = "INSERT INTO `order` (OrderDate, Amount, Status, CustomerID)"
							+ "VALUES ("  + dateText.getText() + ", " +amountText.getText() + ", 0, " + CustIdText.getText() + ")";
					
					String query2 = "INSERT INTO order_by_restaurant (OrderID, RestaurantID)\r\n"
							+ "VALUES ((SELECT OrderID FROM `order` WHERE OrderID=(SELECT max(OrderID) FROM `order`)) , 1);";
					
					String query3 = "INSERT INTO shipment (TimeSent, TimeArrive, Cost, OrderID, DriverID)\r\n"
							+ "VALUES (\"4:00\", \"5:00\", " + amountText.getText() + ", (SELECT OrderID FROM `order` WHERE OrderID=(SELECT max(OrderID) FROM `order`)) , 1);";
					
					stmt.executeUpdate(query);
					stmt.executeUpdate(query2);
					stmt.executeUpdate(query3);
					
					msgLabel.setVisible(true);
					
					stmt.close();
					connection.close();
					
					
					
					
			
					
				} catch(Exception e1) {
					System.out.println(e1);
					
				}
			}
		});
		btnNewButton.setBounds(166, 169, 185, 98);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("Customer ID");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(28, 154, 86, 14);
		contentPane.add(lblNewLabel_2);
		
		CustIdText = new JTextField();
		CustIdText.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		CustIdText.setBounds(28, 179, 100, 20);
		contentPane.add(CustIdText);
		CustIdText.setColumns(10);
		
		lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setIcon(new ImageIcon(NewOrder.class.getResource("/foodDeliverySystem/logo.png")));
		lblNewLabel_3.setBounds(39, 11, 301, 95);
		contentPane.add(lblNewLabel_3);
		
		btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				CustomerMenu customerMenuWindow = new CustomerMenu();
				customerMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setIcon(new ImageIcon(NewOrder.class.getResource("/foodDeliverySystem/back.jpg")));
		btnNewButton_1.setBounds(28, 405, 135, 121);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("New button");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				MainMenu mainMenuWindow = new MainMenu();
				mainMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setIcon(new ImageIcon(NewOrder.class.getResource("/foodDeliverySystem/home.jpg")));
		btnNewButton_2.setBounds(210, 405, 130, 121);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("Credit Card");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(28, 332, 94, 14);
		contentPane.add(lblNewLabel_1_1);
		
		msgLabel = new JLabel("Your order has been placed!!");
		msgLabel.setVisible(false);
		msgLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		msgLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		msgLabel.setBounds(166, 285, 187, 33);
		contentPane.add(msgLabel);
		
		
	}
}
