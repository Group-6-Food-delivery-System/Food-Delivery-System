package foodDeliverySystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DriverMenu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DriverMenu frame = new DriverMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DriverMenu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 393, 539);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(DriverMenu.class.getResource("/foodDeliverySystem/logo.png")));
		lblNewLabel.setBounds(26, 0, 289, 110);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				GetOrderInfo getOrderInfoWindow = new GetOrderInfo();
				getOrderInfoWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBorderPainted(false);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setIcon(new ImageIcon(DriverMenu.class.getResource("/foodDeliverySystem/getOrderInfo.png")));
		btnNewButton.setBounds(10, 131, 176, 110);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New button");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				ConfirmDelivery confirmDeliveryWindow = new ConfirmDelivery();
				confirmDeliveryWindow.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setIcon(new ImageIcon(DriverMenu.class.getResource("/foodDeliverySystem/ConfirmDelivery.png")));
		btnNewButton_1.setBounds(196, 134, 181, 105);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("New Driver Account");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				CreateDriverAccount createDriverWindow = new CreateDriverAccount();
				createDriverWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setIcon(new ImageIcon(DriverMenu.class.getResource("/foodDeliverySystem/CreateAccount.png")));
		btnNewButton_2.setBounds(110, 252, 182, 120);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_4 = new JButton("");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				MainMenu mainMenuWindow = new MainMenu();
				mainMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_4.setIcon(new ImageIcon(DriverMenu.class.getResource("/foodDeliverySystem/home.jpg")));
		btnNewButton_4.setBounds(140, 379, 107, 110);
		contentPane.add(btnNewButton_4);
	}
}
