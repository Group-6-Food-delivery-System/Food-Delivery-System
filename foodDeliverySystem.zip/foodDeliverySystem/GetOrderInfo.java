package foodDeliverySystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import net.proteanit.sql.DbUtils;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.border.MatteBorder;
import javax.swing.border.LineBorder;

public class GetOrderInfo extends JFrame {
	
	static Connection connection = null;
	static String databaseName = "food_delivery_system";
	static String url = "jdbc:mysql://127.0.0.1:3306/?user=root" + databaseName;
	static String username = "root";
	static String password = "AmmiAbbu6353123!";
	

	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JScrollPane scrollPane;
	private JLabel lblNewLabel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GetOrderInfo frame = new GetOrderInfo();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GetOrderInfo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 525, 700);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter your driver identification Number to display your orders");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(63, 111, 409, 14);
		contentPane.add(lblNewLabel);
		
		JTextArea textArea = new JTextArea();
		textArea.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		textArea.setCaretColor(Color.BLACK);
		textArea.setBounds(96, 181, 121, 22);
		contentPane.add(textArea);
		
		scrollPane = new JScrollPane();
		scrollPane.setBorder(new LineBorder(new Color(130, 135, 144)));
		scrollPane.setBounds(42, 257, 430, 211);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Heading1", "New column", "New column", "New column"
			}
		));
		scrollPane.setVisible(false);
		
		btnNewButton = new JButton("Show Orders");
		btnNewButton.setBorderPainted(false);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setIcon(new ImageIcon(GetOrderInfo.class.getResource("/foodDeliverySystem/getOrderInfo.png")));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					
					Class.forName("com.mysql.jdbc.Driver").getDeclaredConstructor().newInstance();
					connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/food_delivery_system?user=root&password=AmmiAbbu6353123!");
					
					String query  = "SELECT DISTINCT R.address AS PickUpLocation, CONCAT(A.Number, ' ',A.Street, ' ',  A.City,' ', A.State, ' ', A.ZipCode) AS DropOffLocation  \r\n"
							+ "FROM shipment AS S JOIN `order` AS O ON (S.OrderID = O.OrderID) "
							+ "JOIN address AS A ON (O.CustomerID = A.CustomerID) "
							+ "JOIN order_by_restaurant AS OBR ON (O.OrderID = OBR.OrderID ) "
							+ "JOIN Restaurant AS R ON (OBR.RestaurantID = R.StoreID) "
							+ "WHERE S.DriverID = '" + textArea.getText() + "' AND O.Status = 0 ;"    ; 
					
					PreparedStatement pst = connection.prepareStatement(query);
					
					ResultSet rs = pst.executeQuery();
					
					table.setModel(DbUtils.resultSetToTableModel(rs));
					scrollPane.setVisible(true);
				} catch(Exception e1) {
					System.out.println(e1);
				}
				
			}
		});
		
		
		btnNewButton.setBounds(306, 135, 166, 114);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("");
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setIcon(new ImageIcon(GetOrderInfo.class.getResource("/foodDeliverySystem/back.jpg")));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				DriverMenu driverMenuWindow = new DriverMenu();
				driverMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(72, 497, 127, 114);
		contentPane.add(btnNewButton_1);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(GetOrderInfo.class.getResource("/foodDeliverySystem/logo.png")));
		lblNewLabel_1.setBounds(99, 11, 300, 89);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_2 = new JButton("New button");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				MainMenu mainMenuWindow = new MainMenu();
				mainMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setIcon(new ImageIcon(GetOrderInfo.class.getResource("/foodDeliverySystem/home.jpg")));
		btnNewButton_2.setBounds(328, 512, 121, 114);
		contentPane.add(btnNewButton_2);
	}
}
