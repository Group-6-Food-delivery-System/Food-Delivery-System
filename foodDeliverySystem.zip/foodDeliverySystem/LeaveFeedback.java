package foodDeliverySystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class LeaveFeedback extends JFrame {
	
	static Connection connection = null;
	static String databaseName = "food_delivery_system";
	static String url = "jdbc:mysql://127.0.0.1:3306/?user=root" + databaseName;
	static String username = "root";
	static String password = "AmmiAbbu6353123!";

	private JPanel contentPane;
	private JTextField custTextField;
	private JTextField driverTextField;
	private JTextField ratingTextField;
	private JTextField commentTextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LeaveFeedback frame = new LeaveFeedback();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LeaveFeedback() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 396, 600);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(LeaveFeedback.class.getResource("/foodDeliverySystem/logo.png")));
		lblNewLabel.setBounds(39, 0, 293, 95);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Leave feedback for a driver here.");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(88, 89, 282, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Customer ID");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(26, 142, 96, 14);
		contentPane.add(lblNewLabel_2);
		
		custTextField = new JTextField();
		custTextField.setBounds(26, 163, 86, 20);
		contentPane.add(custTextField);
		custTextField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Driver ID");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(26, 206, 75, 14);
		contentPane.add(lblNewLabel_3);
		
		driverTextField = new JTextField();
		driverTextField.setBounds(26, 226, 86, 20);
		contentPane.add(driverTextField);
		driverTextField.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Rating (0 to 5)");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_4.setBounds(26, 273, 96, 14);
		contentPane.add(lblNewLabel_4);
		
		ratingTextField = new JTextField();
		ratingTextField.setBounds(26, 290, 86, 20);
		contentPane.add(ratingTextField);
		ratingTextField.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Comment");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_5.setBounds(191, 142, 96, 14);
		contentPane.add(lblNewLabel_5);
		
		commentTextField = new JTextField();
		commentTextField.setBounds(191, 163, 179, 95);
		contentPane.add(commentTextField);
		commentTextField.setColumns(10);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Class.forName("com.mysql.jdbc.Driver").getDeclaredConstructor().newInstance();
					connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/food_delivery_system?user=root&password=AmmiAbbu6353123!");
					
					
					Statement stmt = connection.createStatement();
					
					String query = "INSERT INTO review (`Comment`, Rating, DriverID, CustomerID)\r\n"
							+ "VALUES ('" + commentTextField.getText() + "'," +  
							ratingTextField.getText() + "," + driverTextField.getText() +"," + custTextField.getText() +");";
					
					String query2 = "UPDATE driver\r\n"
							+ "SET TotalRating = (SELECT AVG(review.Rating) FROM review WHERE review.DriverID = driver.DriverNumberID);";
					
					stmt.executeUpdate(query);
					stmt.executeUpdate(query2);
					
					stmt.close();
					connection.close();
					
					custTextField.setText("");
					ratingTextField.setText("");
					driverTextField.setText("");
					commentTextField.setText("");
					
					
				} catch(Exception e1) {
					System.out.println(e1);
				}
				
				
			}
		});
		btnNewButton.setBorderPainted(false);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setIcon(new ImageIcon(LeaveFeedback.class.getResource("/foodDeliverySystem/LeaveFeedback.png")));
		btnNewButton.setBounds(191, 275, 179, 105);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				CustomerMenu cm = new CustomerMenu();
				cm.setVisible(true);
				dispose();
						
			}
		});
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setIcon(new ImageIcon(LeaveFeedback.class.getResource("/foodDeliverySystem/back.jpg")));
		btnNewButton_1.setBounds(56, 403, 130, 121);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				MainMenu mm = new MainMenu();
				mm.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setIcon(new ImageIcon(LeaveFeedback.class.getResource("/foodDeliverySystem/home.jpg")));
		btnNewButton_2.setBounds(219, 403, 124, 121);
		contentPane.add(btnNewButton_2);
	}
}
