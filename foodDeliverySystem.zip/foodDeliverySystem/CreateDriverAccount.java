package foodDeliverySystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class CreateDriverAccount extends JFrame {
	
	static Connection connection = null;
	static String databaseName = "food_delivery_system";
	static String url = "jdbc:mysql://127.0.0.1:3306/?user=root" + databaseName;
	static String username = "root";
	static String password = "AmmiAbbu6353123!";

	private JPanel contentPane;
	private JTextField driverName;
	private JTextField driverAge;
	private JTextField driverAddress;
	private JTextField driverPhone;
	private JTextField driverCar;
	private JTextField driverLicense;
	private JTextField driverHours;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateDriverAccount frame = new CreateDriverAccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreateDriverAccount() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 452, 680);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(CreateDriverAccount.class.getResource("/foodDeliverySystem/logo.png")));
		lblNewLabel.setBounds(59, 11, 329, 105);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Signing up for a driver account");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(111, 101, 206, 31);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Name:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(21, 137, 58, 14);
		contentPane.add(lblNewLabel_2);
		
		driverName = new JTextField();
		driverName.setBounds(21, 160, 236, 20);
		contentPane.add(driverName);
		driverName.setColumns(10);
		
		JLabel lblNewLabel_2_1 = new JLabel("Age:");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2_1.setBounds(286, 143, 58, 14);
		contentPane.add(lblNewLabel_2_1);
		
		driverAge = new JTextField();
		driverAge.setColumns(10);
		driverAge.setBounds(286, 166, 58, 20);
		contentPane.add(driverAge);
		
		JLabel lblNewLabel_2_2 = new JLabel("Address:");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2_2.setBounds(21, 191, 58, 14);
		contentPane.add(lblNewLabel_2_2);
		
		driverAddress = new JTextField();
		driverAddress.setColumns(10);
		driverAddress.setBounds(21, 214, 236, 20);
		contentPane.add(driverAddress);
		
		JLabel lblNewLabel_2_3 = new JLabel("Phone Number:");
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2_3.setBounds(21, 242, 95, 14);
		contentPane.add(lblNewLabel_2_3);
		
		driverPhone = new JTextField();
		driverPhone.setColumns(10);
		driverPhone.setBounds(21, 265, 236, 20);
		contentPane.add(driverPhone);
		
		JLabel lblNewLabel_2_4 = new JLabel("Registered Car:");
		lblNewLabel_2_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2_4.setBounds(21, 296, 121, 14);
		contentPane.add(lblNewLabel_2_4);
		
		driverCar = new JTextField();
		driverCar.setColumns(10);
		driverCar.setBounds(21, 319, 236, 20);
		contentPane.add(driverCar);
		
		JLabel lblNewLabel_2_5 = new JLabel("License ID:");
		lblNewLabel_2_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2_5.setBounds(21, 350, 107, 14);
		contentPane.add(lblNewLabel_2_5);
		
		driverLicense = new JTextField();
		driverLicense.setColumns(10);
		driverLicense.setBounds(21, 373, 236, 20);
		contentPane.add(driverLicense);
		
		JLabel lblNewLabel_2_5_1 = new JLabel("Availble Hours:");
		lblNewLabel_2_5_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2_5_1.setBounds(21, 404, 107, 14);
		contentPane.add(lblNewLabel_2_5_1);
		
		driverHours = new JTextField();
		driverHours.setColumns(10);
		driverHours.setBounds(21, 423, 236, 20);
		contentPane.add(driverHours);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver").getDeclaredConstructor().newInstance();
					connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/food_delivery_system?user=root&password=AmmiAbbu6353123!");
					
					
					Statement stmt = connection.createStatement();
					
					String query = "INSERT INTO `driver` (Name,Address,PhoneNumber,RegisteredCar,LicenseID,Age,AvailableHours,TotalEarnings,TotalRating)"
							+ "VALUES ('" + driverName.getText() + "','" + driverAddress.getText() + "','"
							+ driverPhone.getText() + "','" + driverCar.getText() + "','" + driverLicense.getText()
							+ "','" + driverAge.getText() + "','" + driverHours.getText() + "',0,0);";
					
					stmt.executeUpdate(query);
					
					
					stmt.close();
					connection.close();
					
					driverName.setText("");
					driverAddress.setText("");
					driverPhone.setText("");
					driverCar.setText("");
					driverLicense.setText("");
					driverAge.setText("");
					driverHours.setText("");
					
				}
			 catch(Exception e1) {
				System.out.println(e1);
				}
			}
		});
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setIcon(new ImageIcon(CreateDriverAccount.class.getResource("/foodDeliverySystem/createAccount.png")));
		btnNewButton.setOpaque(false);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setBounds(260, 287, 178, 106);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				DriverMenu driverMenuWindow = new DriverMenu();
				driverMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setIcon(new ImageIcon(CreateDriverAccount.class.getResource("/foodDeliverySystem/back.jpg")));
		btnNewButton_1.setBounds(44, 454, 133, 121);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("New button");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				MainMenu mainMenuWindow = new MainMenu();
				mainMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setIcon(new ImageIcon(CreateDriverAccount.class.getResource("/foodDeliverySystem/home.jpg")));
		btnNewButton_2.setBounds(252, 464, 121, 107);
		contentPane.add(btnNewButton_2);
	}

}
