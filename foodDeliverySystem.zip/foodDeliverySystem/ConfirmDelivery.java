package foodDeliverySystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;

public class ConfirmDelivery extends JFrame {
	
	static Connection connection = null;
	static String databaseName = "food_delivery_system";
	static String url = "jdbc:mysql://127.0.0.1:3306/?user=root" + databaseName;
	static String username = "root";
	static String password = "AmmiAbbu6353123!";

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConfirmDelivery frame = new ConfirmDelivery();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ConfirmDelivery() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 404, 515);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel messageLabel = new JLabel("New label");
		messageLabel.setBackground(Color.WHITE);
		messageLabel.setIcon(new ImageIcon(ConfirmDelivery.class.getResource("/foodDeliverySystem/logo.png")));
		messageLabel.setBounds(44, 11, 287, 90);
		contentPane.add(messageLabel);
		
		JLabel msgLabel = new JLabel("New label");
		msgLabel.setVisible(false);
		msgLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		msgLabel.setBounds(10, 276, 378, 14);
		contentPane.add(msgLabel);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setBorderPainted(false);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setIcon(new ImageIcon(ConfirmDelivery.class.getResource("/foodDeliverySystem/ConfirmDelivery.png")));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				try 
				{
					Class.forName("com.mysql.jdbc.Driver").getDeclaredConstructor().newInstance();
					connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/food_delivery_system?user=root&password=AmmiAbbu6353123!");
					
					Statement stmt = connection.createStatement();
					
					String query = "UPDATE `order` SET Status = 1 WHERE OrderID = " + textField.getText() + ";" ;
					
					stmt.executeUpdate(query);
					
					stmt.close();
					connection.close();
					
					msgLabel.setText("Order Number " + textField.getText() + " delivery has been confirmed ");
					msgLabel.setVisible(true);
					
					
					
					
					
					
					
				}catch (Exception e1) 
				{
					System.out.println(e1);
				}
				
			}
		});
		btnNewButton.setBounds(171, 159, 180, 106);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(75, 204, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Enter Order Idenification to confirm delivery");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(54, 117, 277, 14);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				DriverMenu driverMenuWindow = new DriverMenu();
				driverMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setIcon(new ImageIcon(ConfirmDelivery.class.getResource("/foodDeliverySystem/back.jpg")));
		btnNewButton_1.setBounds(44, 314, 113, 127);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				MainMenu mainMenuWindow = new MainMenu();
				mainMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setIcon(new ImageIcon(ConfirmDelivery.class.getResource("/foodDeliverySystem/home.jpg")));
		btnNewButton_2.setBounds(218, 328, 105, 106);
		contentPane.add(btnNewButton_2);
		
		
		
		
	}
}
