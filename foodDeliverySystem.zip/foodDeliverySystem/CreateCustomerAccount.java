package foodDeliverySystem;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CreateCustomerAccount extends JFrame {
	
	static Connection connection = null;
	static String databaseName = "food_delivery_system";
	static String url = "jdbc:mysql://127.0.0.1:3306/?user=root" + databaseName;
	static String username = "root";
	static String password = "AmmiAbbu6353123!";
	
	private JPanel contentPane;
	private JTextField custName;
	private JTextField custPhone;
	private JTextField custEmail;
	private JTextField custStreetNum;
	private JTextField custAddress;
	private JTextField custCity;
	private JTextField custState;
	private JTextField custZip;
	private JTextField creditCardTextField;
	private JTextField expTextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateCustomerAccount frame = new CreateCustomerAccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreateCustomerAccount() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 554, 750);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(CreateCustomerAccount.class.getResource("/foodDeliverySystem/logo.png")));
		lblNewLabel.setBounds(118, 11, 335, 100);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Sign up for a customer account here!");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(138, 100, 271, 29);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Name:");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(10, 134, 53, 29);
		contentPane.add(lblNewLabel_1_1);
		
		custName = new JTextField();
		custName.setBounds(10, 167, 227, 20);
		contentPane.add(custName);
		custName.setColumns(10);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Phone Number:");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1.setBounds(10, 184, 110, 29);
		contentPane.add(lblNewLabel_1_1_1);
		
		custPhone = new JTextField();
		custPhone.setColumns(10);
		custPhone.setBounds(10, 217, 227, 20);
		contentPane.add(custPhone);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Email:");
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1.setBounds(10, 234, 110, 29);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		custEmail = new JTextField();
		custEmail.setColumns(10);
		custEmail.setBounds(10, 266, 227, 20);
		contentPane.add(custEmail);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Initial Street Number:");
		lblNewLabel_1_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1.setBounds(10, 284, 179, 29);
		contentPane.add(lblNewLabel_1_1_1_1_1);
		
		custStreetNum = new JTextField();
		custStreetNum.setColumns(10);
		custStreetNum.setBounds(10, 317, 227, 20);
		contentPane.add(custStreetNum);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Initial Street Address:");
		lblNewLabel_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1.setBounds(10, 336, 179, 29);
		contentPane.add(lblNewLabel_1_1_1_1_1_1);
		
		custAddress = new JTextField();
		custAddress.setColumns(10);
		custAddress.setBounds(10, 369, 227, 20);
		contentPane.add(custAddress);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1 = new JLabel("Initial City:");
		lblNewLabel_1_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1_1.setBounds(10, 386, 179, 29);
		contentPane.add(lblNewLabel_1_1_1_1_1_1_1);
		
		custCity = new JTextField();
		custCity.setColumns(10);
		custCity.setBounds(10, 419, 227, 20);
		contentPane.add(custCity);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1_1 = new JLabel("Initial State:");
		lblNewLabel_1_1_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_1_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1_1_1.setBounds(10, 444, 179, 29);
		contentPane.add(lblNewLabel_1_1_1_1_1_1_1_1);
		
		custState = new JTextField();
		custState.setColumns(10);
		custState.setBounds(10, 477, 227, 20);
		contentPane.add(custState);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1_1_1 = new JLabel("Initial Zipcode:");
		lblNewLabel_1_1_1_1_1_1_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_1_1_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1_1_1_1.setBounds(10, 497, 179, 29);
		contentPane.add(lblNewLabel_1_1_1_1_1_1_1_1_1);
		
		custZip = new JTextField();
		custZip.setColumns(10);
		custZip.setBounds(10, 530, 227, 20);
		contentPane.add(custZip);
		
		JLabel successMessage = new JLabel("<html>Customer Account<br> Sucessfully created</html>");
		successMessage.setHorizontalAlignment(SwingConstants.CENTER);
		successMessage.setBounds(297, 408, 148, 56);
		contentPane.add(successMessage);
		successMessage.setVisible(false);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver").getDeclaredConstructor().newInstance();
					connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/food_delivery_system?user=root&password=AmmiAbbu6353123!");
					
					Statement stmt = connection.createStatement();
					
					String query = "INSERT INTO `customer` (Name,PhoneNumber,EmailAddress) VALUES ('" + custName.getText() + "','" 
					+ custPhone.getText() + "','" + custEmail.getText() + "');";
					
					String query2 = "INSERT INTO `address` (Number,Street,City,State,ZipCode,CustomerID) VALUES ('" + custStreetNum.getText()
						+ "','" + custAddress.getText() + "','" + custCity.getText() + "','" + custState.getText()
						+ "','" + custZip.getText() + "',(SELECT CustomerID FROM customer WHERE PhoneNumber='" 
						+ custPhone.getText() + "'));";
					
					String query3 = "INSERT INTO creditcardinfo (CardNumber, Expiration, CustomerID)\r\n"
							+ "VALUES ('" + creditCardTextField.getText() +  "'," + expTextField.getText() + ", (SELECT CustomerID FROM customer WHERE CustomerID=(SELECT max(CustomerID) FROM customer)))";
					
					stmt.executeUpdate(query);
					stmt.executeUpdate(query2);
					stmt.executeUpdate(query3);
					
					
					stmt.close();
					connection.close();
					
					custName.setText("");
					custPhone.setText("");
					custEmail.setText("");
					custStreetNum.setText("");
					custAddress.setText("");
					custCity.setText("");
					custState.setText("");
					custZip.setText("");
					creditCardTextField.setText("");
					expTextField.setText("");
					successMessage.setVisible(true);
					
					
				}
			 catch(Exception e1) {
				System.out.println(e1);
				
			}
			}
		});
		btnNewButton.setIcon(new ImageIcon(CreateCustomerAccount.class.getResource("/foodDeliverySystem/createAccount.png")));
		btnNewButton.setBorderPainted(false);
		btnNewButton.setOpaque(false);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBounds(292, 274, 171, 106);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				CustomerMenu customerMenuWindow = new CustomerMenu();
				customerMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setIcon(new ImageIcon(CreateCustomerAccount.class.getResource("/foodDeliverySystem/back.jpg")));
		btnNewButton_1.setBounds(132, 567, 122, 133);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				MainMenu mainMenuWindow = new MainMenu();
				mainMenuWindow.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setIcon(new ImageIcon(CreateCustomerAccount.class.getResource("/foodDeliverySystem/home.jpg")));
		btnNewButton_2.setBounds(314, 585, 110, 115);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Credit Card Number:");
		lblNewLabel_1_1_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_2.setBounds(292, 140, 153, 29);
		contentPane.add(lblNewLabel_1_1_2);
		
		creditCardTextField = new JTextField();
		creditCardTextField.setColumns(10);
		creditCardTextField.setBounds(292, 167, 227, 20);
		contentPane.add(creditCardTextField);
		
		JLabel lblNewLabel_1_1_1_2 = new JLabel("Expiration (YYYYMMDD)");
		lblNewLabel_1_1_1_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_2.setBounds(292, 192, 179, 29);
		contentPane.add(lblNewLabel_1_1_1_2);
		
		expTextField = new JTextField();
		expTextField.setColumns(10);
		expTextField.setBounds(292, 217, 227, 20);
		contentPane.add(expTextField);
		
		
	}
}
